package Demo;

public class sanyuan {
    public static void main(String[] args){
        int a=180;
        int b=200;

        System.out.println((a==b)?"1":"0");
    }
}
