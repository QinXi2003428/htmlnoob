package Demo;

public class variable {
    public static void main(String[] args){
        //定义byte类型
        byte b=10;
        System.out.println(b);

        //定义short类型
        short s=100;
        System.out.println(s);

        //
        int i=10000;
        System.out.println(i);


        //
        double d=13.14;
        System.out.println(d);


        //
        char c='a';
        System.out.println(c);


        //定义boolean类型的变量
        //boolean b=ture;
        //System.out.println(b);


        long l = 1000000000000l;
        System.out.println(l);


        float f=13.14f;
        //System.out.println(f);

    }
}
