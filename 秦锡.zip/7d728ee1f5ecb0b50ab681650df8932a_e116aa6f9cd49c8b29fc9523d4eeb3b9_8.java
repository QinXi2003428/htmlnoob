package Demo;

import java.util.Scanner;
public class shuru {
    public static void main(String[] args){
        //创建对象
        Scanner ll =new Scanner(System.in);

        //接受数据
        //int x=ll.nextInt();
        int x = ll.nextInt();

        //输出数据
        System.out.println("x:"+x);
    }
}
