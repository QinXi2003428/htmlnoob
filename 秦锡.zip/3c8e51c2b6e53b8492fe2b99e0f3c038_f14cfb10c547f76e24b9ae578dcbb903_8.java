package Demo;

public class sanyuan2 {
    public static void main(String[] args) {
        int x = 150;
        int y = 210;
        int z = 165;
        int d = x > y ? x : y;
        int e = d > z ? d : z;
        System.out.println(e);
    }
}