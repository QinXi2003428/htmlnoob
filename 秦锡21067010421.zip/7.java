package 第一课;

public class class1_7 {
    public static void main(String[] args) {
        int a = 180;
        int b = 200;
        boolean c=a==b ? true : false;
        System.out.println(c);
    }
}
