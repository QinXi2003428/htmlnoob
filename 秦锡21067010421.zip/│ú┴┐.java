package 第一课;

public class 常量 {
    public static void main(String[] args){
        //字符串常量
        System.out.println("Hello World!");

        //整数常量
        System.out.println(67);

        //小数常量
        System.out.println(182.23);

        //字符常量
        System.out.println('A');

        //布尔常量
        System.out.println(true);

        //空常量
        //System.out.println(null);
        //空常量不能直接输出
    }
}
