package 第一课;

public class class1_4 {
    public static void main(String[] args){
        int i = (int) 45.23;
        long l = (long) 456.6f;
        char c = (char) 97.14;

        System.out.println(i);
        System.out.println(l);
        System.out.println(c);
    }
}
