package 第一课;

public class T2 {
    public static void main(String[] args){
        char a='g';
        boolean b=a==103;
        System.out.println(b);
    }
}
