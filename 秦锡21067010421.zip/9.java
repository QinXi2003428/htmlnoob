package 第一课;

import java.util.Scanner;

public class class1_9 {
    public static void main(String[] args){
            Scanner sc=new Scanner(System.in);
            int a=sc.nextInt();
            int b=sc.nextInt();
            int c=sc.nextInt();

            int x=a>b?a:b;
            int w=x>c?x:c;
            int s=w>x?w:x;

            System.out.println("最高身高为:"+c);
    }
}
