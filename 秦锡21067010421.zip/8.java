package 第一课;

import java.util.Scanner;

//import java.util.Scanner;
public class class1_8 {
    public static void main(String[] args){
        //创建对象
        Scanner sc = new Scanner(System.in);

        //接收数据
        //int x = sc.nextInt()
        int x = sc.nextInt();

        //输出数据
        System.out.println("x:"+x);
    }
}
